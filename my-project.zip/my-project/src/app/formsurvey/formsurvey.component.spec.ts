import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsurveyComponent } from './formsurvey.component';

describe('FormsurveyComponent', () => {
  let component: FormsurveyComponent;
  let fixture: ComponentFixture<FormsurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormsurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormsurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
