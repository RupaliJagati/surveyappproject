import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-formsurvey',
  templateUrl: './formsurvey.component.html',
  styleUrls: ['./formsurvey.component.css']
})
export class FormsurveyComponent implements OnInit {

  

 
  processLogout(){
    sessionStorage.removeItem('sid');
    this.router.navigate(['login'])
  }
  public fbFormGroup = this.fb.group({
    question1: ['', Validators.required],
    question2: ['', Validators.required],
    question3: ['', Validators.required],
    question4: ['', Validators.required],
    question5: ['', Validators.required],
   
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {}

  async formsubmit() {

    const data = this.fbFormGroup.value;
   
    const url = 'http://localhost:3300/feedbackme';
  
    const res:any=await this.http.post(url, data).toPromise();
    
    this.router.navigate(['ecomsurvey']);
    
  }

}
