import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http'
import { ReactiveFormsModule } from '@angular/forms'
import { LoginComponent } from './login/login.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';

import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { EcomsurveyComponent } from './ecomsurvey/ecomsurvey.component';
import { FoodsurveyComponent } from './foodsurvey/foodsurvey.component';
import { SurveyhereComponent } from './surveyhere/surveyhere.component';
import { FormsurveyComponent } from './formsurvey/formsurvey.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    HomeComponent,
    ErrorPageComponent,
    ForgotpasswordComponent,
    AboutusComponent,
    ContactusComponent,
    EcomsurveyComponent,
    FoodsurveyComponent,
    SurveyhereComponent,
    FormsurveyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
