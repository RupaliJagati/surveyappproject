import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  public fbFormGroup1=this.fb.group({
    username: ['', Validators.required],
    email:['',Validators.required],
   
    password: ['', [Validators.required, Validators.minLength(4)]],
    cpassword: ['', [Validators.required, Validators.minLength(4)]],
    
  });
  
  
    constructor(
      private fb: FormBuilder,
      private router: Router,
      private http: HttpClient) { }
  
  ngOnInit(): void {
  }
  async forgotsubmit() {
    const data = this.fbFormGroup1.value;

    const url = 'http://localhost:3300/forgotuser';
  
    const res:any=await this.http.post(url, data).toPromise();
    if(res.opr){
    this.router.navigate(['login']);
    }
    else{
      
    }
  }

}
