import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';

@Component({
  selector: 'app-ecomsurvey',
  templateUrl: './ecomsurvey.component.html',
  styleUrls: ['./ecomsurvey.component.css']
})
export class EcomsurveyComponent{

  constructor(private router : Router, private http : HttpClientModule) { }

    myform(){
      this.router.navigate(['formsurvey']);
    }
    processLogout(){
      sessionStorage.removeItem('sid');
      this.router.navigate(['login'])
    }
  

}
