import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EcomsurveyComponent } from './ecomsurvey.component';

describe('EcomsurveyComponent', () => {
  let component: EcomsurveyComponent;
  let fixture: ComponentFixture<EcomsurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EcomsurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EcomsurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
