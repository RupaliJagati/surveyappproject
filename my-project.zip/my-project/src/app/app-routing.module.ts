import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';

import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { EcomsurveyComponent } from './ecomsurvey/ecomsurvey.component';
import { FoodsurveyComponent } from './foodsurvey/foodsurvey.component';
import { SurveyhereComponent } from './surveyhere/surveyhere.component';
import { FormsurveyComponent } from './formsurvey/formsurvey.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'home',component: HomeComponent,
  children: [
    { path: '', component:SurveyhereComponent},
    { path: 'aboutus', component: AboutusComponent },
    { path: 'contactus', component:  ContactusComponent },
  ],
    },
  {path:'forgotpassword',component:ForgotpasswordComponent},
  { path: 'ecomsurvey', component: EcomsurveyComponent },
  //{ path: 'aboutus', component: AboutusComponent },
  //{ path: 'contactus', component: ContactusComponent },
  { path: 'foodsurvey', component: FoodsurveyComponent},
  { path: 'formsurvey', component: FormsurveyComponent},


   /* children: [
      { path: '', component: PersonalInfoComponent },
      { path: 'education', component: EducationComponent },
      { path: 'contact-us', component: ContactUsComponent },
    ],
  },*/
  { path: '**', component: ErrorPageComponent },
  //{ path: '', redirectTo: '/login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
