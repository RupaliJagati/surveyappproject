import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-register',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
})
export class RegistrationComponent implements OnInit {
  forbiddenEmails: any;
  public uiInvalidCredential = false;

  public fbFormGroup = this.fb.group({
    username: ['', Validators.required,Validators.pattern('[a-zA-Z]*')],
    password: ['', [Validators.required, Validators.minLength(4)]],
    cpassword: ['', [Validators.required, Validators.minLength(4)]],
    email: ['',  [Validators.required, Validators.email,
      Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")], this.forbiddenEmails],
    mobile: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {}

  async registeruser() {

    const data = this.fbFormGroup.value;
    if(data.password==data.cpassword){
    const url = 'http://localhost:3300/adduser';
  
    const res:any=await this.http.post(url, data).toPromise();
    
    this.router.navigate(['login']);
    }
  }
}
