import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

import {HttpClientModule} from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent{

  constructor(private router : Router, private http : HttpClientModule) { }
  ngOnInit(): void {
    if (!sessionStorage.getItem('sid')) {
      this.router.navigate(['login']);
    }
  }

  processLogout(){
    sessionStorage.removeItem('sid');
    this.router.navigate(['login'])
  }

 
 
  gotoPage(page){
    this.router.navigate([page]);
  }

}

