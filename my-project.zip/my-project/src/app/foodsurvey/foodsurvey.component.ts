import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {HttpClientModule} from '@angular/common/http'

@Component({
  selector: 'app-foodsurvey',
  templateUrl: './foodsurvey.component.html',
  styleUrls: ['./foodsurvey.component.css']
})
export class FoodsurveyComponent {

  constructor(private router : Router, private http : HttpClientModule) { }

  gotoPage(page){
    this.router.navigate([page]);
  }

}
