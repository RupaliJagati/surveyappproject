import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodsurveyComponent } from './foodsurvey.component';

describe('FoodsurveyComponent', () => {
  let component: FoodsurveyComponent;
  let fixture: ComponentFixture<FoodsurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodsurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodsurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
