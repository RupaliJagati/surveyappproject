import { Component, OnInit } from '@angular/core';
import { faFacebook,faTwitter,faInstagram } from '@fortawesome/free-brands-svg-icons';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public faFacebook = faFacebook;
  public faTwitter=faTwitter;
  public faInstagram =faInstagram ;

  public uiInvalidCredential = false;

 public fbFormGroup=this.fb.group({
  username: ['', [Validators.compose([Validators.maxLength(30), Validators.pattern('[a-zA-Z]*'), Validators.required])]],
  password: ['', [Validators.required, Validators.minLength(4),Validators.maxLength(8)]],
});


  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient) { }

  ngOnInit(): void {
  }
 

  
  async loginProcessHere() {
    const data = this.fbFormGroup.value;

    // ajax call
    const url = 'http://localhost:3300/auth-user';
    const result: any = await this.http.post(url, data).toPromise();
    if (result.opr) {
      sessionStorage.setItem('sid', 'true');
      this.router.navigate(['home']);
    } else {
      this.uiInvalidCredential = true;
    }
  }

}
