import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

import {HttpClientModule} from '@angular/common/http';

@Component({
  selector: 'app-surveyhere',
  templateUrl: './surveyhere.component.html',
  styleUrls: ['./surveyhere.component.css']
})
export class SurveyhereComponent implements OnInit {

  constructor(private router : Router, private http : HttpClientModule) { }

  ngOnInit(): void {
  }
  gotoPage(page){
    this.router.navigate([page]);
  }

}
