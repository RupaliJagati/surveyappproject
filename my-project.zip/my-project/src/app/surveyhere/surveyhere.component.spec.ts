import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveyhereComponent } from './surveyhere.component';

describe('SurveyhereComponent', () => {
  let component: SurveyhereComponent;
  let fixture: ComponentFixture<SurveyhereComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveyhereComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveyhereComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
