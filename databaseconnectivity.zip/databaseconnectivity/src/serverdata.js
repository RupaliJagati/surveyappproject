
const dbadd=require("./read");

const express = require("express");
const cors = require("cors");
const multer = require("multer");

const app = express();


app.use(cors());
app.use(express.json()); 
app.use(express.urlencoded({ extended: true })); 
const upload = multer(); 

app.post("/adduser", async (req, res) => {
  try {
    const input = req.body; 
  console.log(input)
    await dbadd.addUser(input);
    res.json({ message: "success post" });
  } catch (err) {
    res.json({ message: "failure post" });
  }
});

app.post("/auth-user", async (req, res) => {
  try {
    const input = req.body;

    await dbadd.authenticateUser(input);
    res.json({ opr: true });
  } catch (err) {
    res.json({ opr: false });
  }
});

app.post("/forgotuser", async (req, res) => {
  try {
    const input = req.body;

    await dbadd.forgotpassuser(input);
    res.json({ opr: true });
  } catch (err) {
    res.json({ opr: false });
  }
});

app.post("/feedbackme", async (req, res) => {
  try {
    const input = req.body;

    await dbadd.addfeedback(input);
    res.json({ opr: true });
  } catch (err) {
    res.json({ opr: false });
  }
});



app.post("/sample", upload.none(), async (req, res) => {
  res.json(req.body);
});
app.get("/",(req,res)=>{
  res.json({my:"qppp"})
})

// started teh server.
app.listen(3300);