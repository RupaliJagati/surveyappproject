const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {
  host: "localhost",
  user: "root",
  password: "",
  database: "servey",
};

let addUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql =
    "INSERT INTO REGISTER (USERNAME, PASSWORD,CPASSWORD, EMAIL, MOBILE) VALUES (?, ?, ?,?, ?)";
  await connection.queryAsync(sql, [
    input.username,
    input.password,
    input.cpassword,
    input.email,
    input.mobile,
  ]);

  await connection.endAsync();
};

let authenticateUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql = "SELECT * FROM REGISTER WHERE USERNAME=? AND PASSWORD=?";
  const results = await connection.queryAsync(sql, [
    input.username,
    input.password,
  ]);

  await connection.endAsync();

  if (results.length === 0) {
    throw new Error("Invalid Credentials");
  }
};



let forgotpassuser = async (input) => {
 // console.log(input);
 const connection = mysql.createConnection(DB_CONFIG);
 await connection.connectAsync();

    if(input.password!=input.cpassword){
      throw new Error("invalid confirmpassword");
    }

    let sql = "UPDATE REGISTER SET PASSWORD=?,CPASSWORD=? WHERE EMAIL=? AND USERNAME=?";
    let results= await connection.queryAsync(sql, [
  
    input.password,
    input.cpassword,
    input.email,
    input.username,
  
    
  ]);

  await connection.endAsync();

  if(results.length===0){
    throw new Error("Invalid Credential");
    }
};
let addfeedback = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql =
    "INSERT INTO FEEDBACK(QUESTION1, QUESTION2,QUESTION3, QUESTION4, QUESTION5) VALUES (?, ?, ?,?, ?)";
  await connection.queryAsync(sql, [
    input.question1,
    input.question2,
    input.question3,
    input.question4,
    input.question5,
  ]);

  await connection.endAsync();
};


module.exports = { addUser, authenticateUser ,forgotpassuser,addfeedback};